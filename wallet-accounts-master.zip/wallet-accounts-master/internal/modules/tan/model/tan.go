package model

type Tan struct {
	ID  int64
	Tan string
	UID string
}

type TanSubscriber struct {
	ID  int64
	UID string
}
