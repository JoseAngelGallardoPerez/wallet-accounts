package calculation

func Providers() []interface{} {
	return []interface{}{
		NewRounding,
	}
}
