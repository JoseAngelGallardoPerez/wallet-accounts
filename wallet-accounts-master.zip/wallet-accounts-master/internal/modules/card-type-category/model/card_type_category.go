package model

type CardTypeCategory struct {
	Id   *uint32 `json:"id"`
	Name *string `json:"name"`
}
