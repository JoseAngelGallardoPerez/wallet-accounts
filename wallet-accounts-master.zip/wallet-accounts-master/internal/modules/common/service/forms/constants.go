package forms

const (
	TypeFormPost = "post"
	TypeFormPut  = "put"
)
