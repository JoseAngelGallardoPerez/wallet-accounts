package notifications

type Setting struct {
	Name  string
	Value string
}
