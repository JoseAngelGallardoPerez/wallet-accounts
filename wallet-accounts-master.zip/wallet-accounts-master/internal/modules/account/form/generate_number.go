package form

type GenerateNumber struct {
	Prefix *string `json:"prefix"`
}
