package limit

// Model contains limit data
type Model struct {
	Identifier
	Value Value
}
